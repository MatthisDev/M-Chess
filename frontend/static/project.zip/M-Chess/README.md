# M&Chess

Chess Game in Rust - S4 Project EPITA

## Members

| Name            | Email                    | Github                                        |
|-----------------|--------------------------|-----------------------------------------------|
| Matthis Guillet | matthis.guillet@epita.fr | [MatthisDev](https://github.com/MatthisDev)   |
| Martin Madier   | martin.madier@epita.fr   | [marmads](https://github.com/marmads)         |
| Martin Pasquier | martin.pasquier@epita.fr | [Marty42780](https://github.com/Marty42780)   |
| Matteo Wermert  | matteo.wermert@epita.fr  | [FireBlade60](https://github.com/FireBlade60) |
